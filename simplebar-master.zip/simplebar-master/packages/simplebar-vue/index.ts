import simplebar from './component';

export default simplebar;
