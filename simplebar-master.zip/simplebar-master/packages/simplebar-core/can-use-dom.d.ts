declare module 'can-use-dom';
