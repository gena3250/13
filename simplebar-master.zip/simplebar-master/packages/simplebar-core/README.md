# SimpleBar Core

- **🐦 Follow me on [Twitter!](https://twitter.com/adriendenat) or [Mastodon!](https://mas.to/@adrien)**
- **👨‍💻 I'm available for hire! [Reach out to me!](https://adriendenat.com/)**
- **🚧 Check out my new project [Scroll Snap Carousel](https://github.com/Grsmto/scroll-snap-carousel)!**

### This is the core library. You should not use it directly. If you want the vanilla plugin, see [SimpleBar](https://github.com/Grsmto/simplebar/tree/master/packages/simplebar).
