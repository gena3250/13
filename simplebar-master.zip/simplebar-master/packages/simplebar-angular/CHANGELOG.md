# v3.2.4 (Sat Apr 15 2023)

#### 🐛 Bug Fix

- Update CHANGELOG.md \[skip ci\] ([@Grsmto](https://github.com/Grsmto))

#### ⚠️ Pushed to `master`

- Publish ([@Grsmto](https://github.com/Grsmto))
- feat(angular): downgrade back to Angular version 12 for better support ([@Grsmto](https://github.com/Grsmto))
- Revert "chore: remove unnecessary build step" ([@Grsmto](https://github.com/Grsmto))
- chore(core, react, vue, angular): set missing accessibility properties ([@Grsmto](https://github.com/Grsmto))
- chore: update READMEs ([@Grsmto](https://github.com/Grsmto))

#### Authors: 1

- Adrien Denat ([@Grsmto](https://github.com/Grsmto))

---

# v3.2.3 (Wed Mar 29 2023)

#### 🐛 Bug Fix

- Update CHANGELOG.md \[skip ci\] ([@Grsmto](https://github.com/Grsmto))

#### ⚠️ Pushed to `master`

- Publish ([@Grsmto](https://github.com/Grsmto))
- feat(angular): downgrade back to Angular version 12 for better support ([@Grsmto](https://github.com/Grsmto))
- Revert "chore: remove unnecessary build step" ([@Grsmto](https://github.com/Grsmto))
- chore(core, react, vue, angular): set missing accessibility properties ([@Grsmto](https://github.com/Grsmto))
- chore: update READMEs ([@Grsmto](https://github.com/Grsmto))

#### Authors: 1

- Adrien Denat ([@Grsmto](https://github.com/Grsmto))

---

# v3.2.2 (Sun Mar 19 2023)

#### 🐛 Bug Fix

- Update CHANGELOG.md \[skip ci\] ([@Grsmto](https://github.com/Grsmto))

#### ⚠️ Pushed to `master`

- Publish ([@Grsmto](https://github.com/Grsmto))
- feat(angular): downgrade back to Angular version 12 for better support ([@Grsmto](https://github.com/Grsmto))
- Revert "chore: remove unnecessary build step" ([@Grsmto](https://github.com/Grsmto))
- chore(core, react, vue, angular): set missing accessibility properties ([@Grsmto](https://github.com/Grsmto))
- chore: update READMEs ([@Grsmto](https://github.com/Grsmto))

#### Authors: 1

- Adrien Denat ([@Grsmto](https://github.com/Grsmto))

---

# v3.2.1 (Sat Feb 11 2023)

#### 🐛 Bug Fix

- Update CHANGELOG.md \[skip ci\] (oi@adriendenat.com)

#### ⚠️ Pushed to `master`

- feat(angular): downgrade back to Angular version 12 for better support (oi@adriendenat.com)
- Publish (oi@adriendenat.com)
- Revert "chore: remove unnecessary build step" (oi@adriendenat.com)
- chore(core, react, vue, angular): set missing accessibility properties (oi@adriendenat.com)
- chore: update READMEs (oi@adriendenat.com)

#### Authors: 1

- Adrien Denat ([@Grsmto](https://github.com/Grsmto))

---

# v3.2.1 (Sat Feb 11 2023)

#### ⚠️ Pushed to `master`

- feat(angular): downgrade back to Angular version 12 for better support ([@Grsmto](https://github.com/Grsmto))
- Publish ([@Grsmto](https://github.com/Grsmto))
- Revert "chore: remove unnecessary build step" ([@Grsmto](https://github.com/Grsmto))
- chore(core, react, vue, angular): set missing accessibility properties ([@Grsmto](https://github.com/Grsmto))
- chore: update READMEs ([@Grsmto](https://github.com/Grsmto))

#### Authors: 1

- Adrien Denat ([@Grsmto](https://github.com/Grsmto))
