import { NgModule } from '@angular/core';
import { SimplebarAngularComponent } from './simplebar-angular.component';

@NgModule({
  declarations: [SimplebarAngularComponent],
  imports: [],
  exports: [SimplebarAngularComponent],
  schemas: [],
})
export class SimplebarAngularModule {}
